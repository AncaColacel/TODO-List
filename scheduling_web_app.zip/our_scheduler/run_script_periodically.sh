#!/bin/bash

# while :
# do
    python3 cron.py
    # sleep 60
# done