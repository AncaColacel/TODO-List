from flask import Flask

app = Flask(__name__)
app.config['SECRET_KEY'] = '$2y$10$FTcZyIvMrYHWlbW8PzN93uYltwtOGAqF3xmgdImoVDuhmtsxhOBtG'